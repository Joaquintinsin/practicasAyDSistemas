public  class Filtro{
    private Api api;

    public Filtro(){}
    public Api getApi(){
        return api;
    }

    public void setApi(Api api){
        this.api = api;
    }

    public  void execute(Imagen i){};
}
