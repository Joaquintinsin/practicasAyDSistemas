public class Imagen{
    private String name="";

    public Imagen(String n){
        this.name = n;

    }

}