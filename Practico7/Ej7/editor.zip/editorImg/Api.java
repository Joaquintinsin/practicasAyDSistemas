public class Api{

    
    public void ilumninar(Imagen i){
                System.out.println("... iluminando ...");

    }

    public void quitarOjosRojos(Imagen i){
                System.out.println("..quitando ojos rojos...");

    }

    public void colorearBordes(Imagen i){
        System.out.println(" ..coloreando bordes...");

}

    public void suavizarBordes(Imagen i){
                System.out.println(" ... suavizando bordes ...");

    }
    public void difuminarFondo(Imagen i){
                System.out.println(" ....difuminando fondo...");

    }
    public void agregarLuz(Imagen i){
                System.out.println("... aplicando agregar luz...");

    }

    public void aplicarSepia(Imagen i){
        System.out.println("... aplicando color sepia ...");
    }

    public void aplicarBlancoNegro(Imagen i){
        System.out.println("... aplicando color blanco y negro...");
    }

}